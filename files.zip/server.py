# Servidor de trimo.ai: descarga el vídeo del enlace y sirve la web.
# Requisitos: Python 3, ffmpeg instalado y:  pip install flask yt-dlp
# Uso:  python server.py   y abre  http://localhost:8000
import os, re, subprocess, sys
from flask import Flask, request, jsonify, send_from_directory
B = os.path.dirname(os.path.abspath(__file__)); D = os.path.join(B, "downloads"); os.makedirs(D, exist_ok=True)
app = Flask(__name__)

@app.get("/")
def home(): return send_from_directory(B, "index.html")

@app.get("/api/ping")
def ping(): return "ok"

@app.post("/api/download")
def dl():
    u = (request.json or {}).get("url", "")
    m = re.search(r"(?:youtu\.be/|v=|shorts/|embed/)([\w-]{11})", u)
    if not m: return jsonify(error="Enlace no válido"), 400
    v = m.group(1); f = os.path.join(D, v + ".mp4")
    if not os.path.exists(f):
        r = subprocess.run([sys.executable, "-m", "yt_dlp", "-f",
            "bv*[height<=1080][vcodec^=avc1]+ba[ext=m4a]/b[ext=mp4]/b", "--merge-output-format", "mp4",
            "--no-playlist", "-o", f, "https://www.youtube.com/watch?v=" + v], capture_output=True, text=True)
        if r.returncode or not os.path.exists(f):
            return jsonify(error="No se pudo descargar: " + r.stderr[-200:]), 500
    return jsonify(file="/media/" + v + ".mp4")

@app.get("/media/<n>")
def media(n): return send_from_directory(D, n, conditional=True)

app.run(host="0.0.0.0", port=8000)
